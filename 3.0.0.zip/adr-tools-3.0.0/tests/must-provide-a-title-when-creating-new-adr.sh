if adr new
then
    echo ERROR: should have failed
fi
