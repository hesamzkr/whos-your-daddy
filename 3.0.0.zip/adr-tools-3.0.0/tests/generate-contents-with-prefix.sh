adr new First Decision
adr new Second Decision
adr new Third Decision
adr generate toc -p foo/doc/adr/
