adr new First Decision
adr new Second Decision
adr new Third Decision
ls doc/adr
head -7 doc/adr/0002-second-decision.md
head -7 doc/adr/0003-third-decision.md
